package com.example.rest;

import com.example.rest.model.CreditCard;
import com.example.rest.model.Rewards;
import com.example.rest.model.Transaction;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CreditCardService {

    public CreditCard getCreditCard(String cardId) {
        // Fetch credit card details from the database
        return new CreditCard(cardId, "1234-5678-9876-5432", "Visa", 1200.50, 5000.00);
    }

    public List<Transaction> getTransactions(String cardId, int limit) {
        // Fetch transactions from the database
        return List.of(
                new Transaction("t1", "2024-01-01", -50.00, "Grocery Store"),
                new Transaction("t2", "2024-01-02", 200.00, "Salary"),
                new Transaction("t3", "2024-01-03", -75.00, "Restaurant"),
                new Transaction("t4", "2024-01-04", -20.00, "Taxi"),
                new Transaction("t5", "2024-01-05", -150.00, "Electronics"),
                new Transaction("t6", "2024-01-06", -60.00, "Clothing"),
                new Transaction("t7", "2024-01-07", -30.00, "Gas"),
                new Transaction("t8", "2024-01-08", -10.00, "Coffee"),
                new Transaction("t9", "2024-01-09", -25.00, "Books"),
                new Transaction("t10", "2024-01-10", -90.00, "Groceries")
        ).subList(0, Math.min(limit, 10));
    }

    public Rewards getRewards(String cardId) {
        // Fetch rewards from the database
        return new Rewards(500, "Gold");
    }
}
